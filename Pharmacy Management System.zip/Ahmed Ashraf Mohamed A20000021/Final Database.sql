CREATE DATABASE pharmacy;

USE pharmacy;

CREATE TABLE drug_drug_interactions (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  drug_1 VARCHAR(255) NOT NULL,
  drug_2 VARCHAR(255) NOT NULL,
  interaction VARCHAR(255) NOT NULL,
  severity VARCHAR(255) NOT NULL
);

CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    price FLOAT,
    quantity INT
);

CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255),
    address VARCHAR(255),
    contact VARCHAR(255)
);

CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    medicine_id INT,
    quantity INT,
    total_price FLOAT,
    date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    amount FLOAT,
    payment_method VARCHAR(255),
    transaction_date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE prescription (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_name VARCHAR(255),
    doctor_name VARCHAR(255),
    medicine_id INT,
    dosage VARCHAR(255),
    refill_information VARCHAR(255),
    date_prescribed DATE,
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);

CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT,
    medicine_id INT,
    quantity INT,
    total_price FLOAT,
    date DATE,
    FOREIGN KEY (customer_id) REFERENCES customers(id),
    FOREIGN KEY (medicine_id) REFERENCES medicines(id)
);
INSERT INTO medicines (name, price, quantity) VALUES
('Panadol', 5.5, 100),
('Nurofen', 8.25, 50),
('Augmentin', 23.75, 20),
('Ventolin', 12.0, 30),
('Advil', 7.5, 75),
('Zyrtec', 10.0, 40),
('Lipitor', 15.5, 25),
('Crestor', 17.25, 30),
('Plavix', 20.0, 15),
('Nexium', 12.75, 35),
('Synthroid', 8.0, 50),
('Singulair', 14.5, 20),
('ProAir', 10.25, 25),
('Prozac', 9.75, 35),
('Zocor', 16.0, 20),
('Lisinopril', 7.0, 50),
('Metformin', 6.5, 60),
('Loratadine', 5.75, 70),
('Clonazepam', 12.0, 30),
('Ativan', 14.5, 25);
INSERT INTO customers (name, address, contact) VALUES
('محمد احمد', 'شارع النزهة، القاهرة', '01012345678'),
('فاطمة علي', 'شارع الحرية، الجيزة', '01123456789'),
('عمرو خالد', 'شارع العشرين، المعادي', '01234567890'),
('نورهان محمد', 'شارع الجيش، الزيتون', '01098765432'),
('محمد مصطفى', 'شارع الكورنيش، الإسكندرية', '01187654321'),
('ريم حسين', 'شارع النيل، الجيزة', '01234567891'),
('محمد علي', 'شارع الأهرام، الجيزة', '01011223344'),
('ياسمين عمر', 'شارع مصر الجديدة، القاهرة', '01122334455'),
('أسماء محمود', 'شارع الهرم، الجيزة', '01233445566'),
('محمد عماد', 'شارع السودان، الزمالك', '01098765432'),
('نوران عبدالله', 'شارع العروبة، المهندسين', '01122334455'),
('أنس عزت', 'شارع الأزهر، القاهرة', '01234567891'),
('رانيا ناصر', 'شارع رمسيس، القاهرة', '01011223344'),
('أحمد محمود', 'شارع العباسية، القاهرة', '01187654321'),
('سلمى عبدالله', 'شارع النيل، المعادي', '01233445566'),
('محمد حسن', 'شارع الجيش، الزيتون', '01098765432'),
('ريم علي', 'شارع الكورنيش، الإسكندرية', '01122334455'),
('أحمد علي', 'شارع النيل، الجيزة', '01234567891'),
('خالد محمد', 'شارع الأهرام، الجيزة', '01011223344');
INSERT INTO orders (customer_id, medicine_id, quantity, total_price, date) VALUES
(1, 1, 3, 16.5, '2023-05-01'),
(1, 4, 2, 24.0, '2023-05-03'),
(2, 5, 1, 7.5, '2023-05-02'),
(3, 3, 5, 118.75, '2023-05-01'),
(3, 7, 1, 15.5, '2023-05-03'),
(4, 2, 4, 33.0, '2023-05-01'),
(4, 6, 3, 30.0, '2023-05-02'),
(4, 8, 2, 34.5, '2023-05-03'),
(5, 9, 1, 20.0, '2023-05-02'),
(5, 10, 2, 25.5, '2023-05-03'),
(6, 11, 3, 24.0, '2023-05-01'),
(6, 12, 2, 29.0, '2023-05-02'),
(7, 13, 1, 10.25, '2023-05-01'),
(7, 14, 2, 19.5, '2023-05-03'),
(8, 15, 1, 16.0, '2023-05-02'),
(8, 16, 3, 21.0, '2023-05-03'),
(9, 17, 2, 14.0, '2023-05-01'),
(9, 18, 1, 6.5, '2023-05-02'),
(9, 19, 3, 17.25, '2023-05-03'),
(10, 20, 2, 29.0, '2023-05-02');
INSERT INTO payments (customer_id, amount, payment_method, transaction_date) VALUES
(1, 10.0, 'cash', '2023-05-01'),
(2, 7.5, 'credit card', '2023-05-02'),
(3, 50.0, 'cash', '2023-05-03'),
(4, 75.0, 'debit card', '2023-05-03'),
(5, 20.0, 'cash', '2023-05-02'),
(6, 30.0, 'cash', '2023-05-01'),
(7, 10.25, 'debit card', '2023-05-01'),
(8, 16.0, 'credit card', '2023-05-02'),
(9, 10.0, 'cash', '2023-05-03'),
(10, 25.5, 'debit card', '2023-05-02');
INSERT INTO prescription (patient_name, doctor_name, medicine_id, dosage, refill_information, date_prescribed) VALUES
('أحمد محمد', 'دكتور أحمد علي', 1, '2 tablets every 6 hours', 'No refills', '2023-04-29'),
('ريم حسين', 'دكتورة ياسمين عمر', 2, '1 tablet every 8 hours', '3 refills', '2023-04-30'),
('محمد احمد', 'دكتور عمرو خالد', 3, '1 tablet every 12 hours', 'No refills', '2023-05-01'),
('نورهان محمد', 'دكتورة فاطمة علي', 4, '2 puffs every 4 hours', 'No refills', '2023-05-02'),
('فاطمة علي', 'دكتور محمد احمد', 5, '2 tablets every 6 hours', '2 refills', '2023-05-02'),
('عمرو خالد', 'دكتور محمد مصطفى', 6, '1 tablet every 12 hours', 'No refills', '2023-05-03'),
('محمد مصطفى', 'دكتورة رنا ناصر', 7, '1 tablet every 8 hours', '1 refill', '2023-05-03'),
('ريم علي', 'دكتور خالد محمد', 8, '2 tablets every 6 hours', 'No refills', '2023-05-03'),
('نوران عبدالله', 'دكتورة ريم حسين', 9, '1 tablet every 12 hours', '2 refills', '2023-05-03'),
('أحمد علي', 'دكتورة أسماء محمود', 10, '1 tablet every 8 hours','2 refills', '2023-05-03');
INSERT INTO sales (customer_id, medicine_id, quantity, total_price, date) VALUES
(1, 1, 2, 11.0, '2023-05-01'),
(1, 4, 1, 12.0, '2023-05-03'),
(2, 5, 1, 7.5, '2023-05-02'),
(3, 3, 3, 71.25, '2023-05-01'),
(3, 7, 1, 15.5, '2023-05-03'),
(4, 2, 2, 16.5, '2023-05-01'),
(4, 6, 2, 20.0, '2023-05-02'),
(4, 8, 1, 17.25, '2023-05-03'),
(5, 9, 1, 20.0, '2023-05-02'),
(5, 10, 2, 25.5, '2023-05-03'),
(6, 11, 2, 16.0, '2023-05-01'),
(6, 12, 1, 14.5, '2023-05-02'),
(7, 13, 1, 10.25, '2023-05-01'),
(7, 14, 1, 9.75, '2023-05-03'),
(8, 15, 1, 16.0, '2023-05-02'),
(8, 16, 2, 10.5, '2023-05-03'),
(9, 17, 1, 7.0, '2023-05-01'),
(9, 18, 1, 6.5, '2023-05-02'),
(9, 19, 2, 11.5, '2023-05-03'),
(10, 20, 2, 29.0, '2023-05-02');

INSERT INTO drug_drug_interactions (drug_1, drug_2, interaction, severity) VALUES
('Warfarin', 'Aspirin', 'Increased risk of bleeding', 'Serious'),
('Digoxin', 'Quinidine', 'Increased risk of digoxin toxicity', 'Serious'),
('MAOI', 'Meperidine', 'Increased risk of serotonin syndrome', 'Serious'),
('Lithium', 'Thiazide diuretics', 'Increased risk of lithium toxicity', 'Serious'),
('Phenytoin', 'Carbamazepine', 'Decreased effect of phenytoin', 'Moderate'),
('Warfarin', 'Grapefruit juice', 'Increased risk of bleeding', 'Moderate'),
('Cyclosporine', 'Grapefruit juice', 'Decreased effect of cyclosporine', 'Moderate'),
('Rifampin', 'Oral contraceptives', 'Decreased effect of oral contraceptives', 'Moderate'),
('Antacids', 'Tetracyclines', 'Decreased absorption of tetracyclines', 'Mild'),
('Proton pump inhibitors', 'Iron supplements', 'Decreased absorption of iron supplements', 'Mild');